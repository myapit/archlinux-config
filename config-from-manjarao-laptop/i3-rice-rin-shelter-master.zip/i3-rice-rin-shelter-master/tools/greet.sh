#!/bin/sh
screenfetch -N
$SHELL
