#!/usr/bin/sh
echo "[Safety Protocol]"
echo "Checking Update....."
sudo pacman -Syyu
$SHELL
