#!/usr/bin/sh
exec st -ai -e myautoupdate.sh
